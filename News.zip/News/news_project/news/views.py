from django.shortcuts import render
from news_admin.views import news_list as news_list_view
from news_admin.models import NewsArticle


def index(request):
    return render(request, 'index.html')

def contact(request):
    return render(request, 'contact.html')

def single_page(request):
    articles = NewsArticle.objects.all()

    return render(request,'single_page.html',{'articles': articles})