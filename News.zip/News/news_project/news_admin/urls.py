# 
from django.urls import path
from . import views

urlpatterns = [
    path('news/', views.news_list, name='news_list'),
    path('news/create/', views.create_news, name='create_news'),
    path('news/<int:pk>/update/', views.update_news, name='update_news'),
    path('news/<int:pk>/delete/', views.delete_news, name='delete_news'),
] 

