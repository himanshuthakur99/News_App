from django.shortcuts import render, get_object_or_404, redirect
from .models import NewsArticle
from .forms import NewsArticleForm

def news_list(request):
    articles = NewsArticle.objects.all()
    return render(request, 'news_list.html', {'articles': articles})

def create_news(request):
    if request.method == 'POST':
        form = NewsArticleForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('news_list')
    else:
        form = NewsArticleForm()
    return render(request, 'create_news.html', {'form': form})

def update_news(request, pk):
    article = get_object_or_404(NewsArticle, pk=pk)
    if request.method == 'POST':
        form = NewsArticleForm(request.POST, request.FILES, instance=article)
        if form.is_valid():
            form.save()
            return redirect('news_list')
    else:
        form = NewsArticleForm(instance=article)
    return render(request, 'update_news.html', {'form': form})

def delete_news(request, pk):
    article = get_object_or_404(NewsArticle, pk=pk)
    if request.method == 'POST':
        article.delete()
        return redirect('news_list')
    return render(request, 'delete_news.html', {'article': article})
